from setuptools import setup, find_packages

setup(
    name="TClienteFacil+Salvatierra",
    version="0.2",
    packages=find_packages(),
    description="Un paquete para modelar clientes en una página de compras llamada CompraFácil",
    author='Paulo Salvatierra',
    author_email='paulosalvatierra.com',
)