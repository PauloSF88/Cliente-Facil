from setuptools import setup, find_packages

setup(
    name='cliente_paquete',
    version='0.1',
    packages=find_packages(),
    description='Cliente Facil',
    author='Paulo Salvatierra',
    author_email='paulosalvatierra.com',
)